import Link from 'next/link';
import { Instagram } from 'lucide-react';
import { restaurant } from '@/lib/siteData';

export default function Footer(){
  return <footer className="footer">
    <div className="container">
      <div className="footer-grid">
        <div>
          <h4>Roswell Ale House</h4>
          <p>A neighborhood sports bar built for game days, cold drinks, good food, and late-night energy.</p>
          <Link href="/careers">Careers →</Link>
        </div>
        <div>
          <h4>Hours</h4>
          {restaurant.hours.map(([d,h])=><p key={d}><strong>{d}</strong><br/>{h}</p>)}
        </div>
        <div>
          <h4>Find Us On</h4>
          <div className="socials">
            <a href={restaurant.social.instagram} aria-label="Instagram"><Instagram size={18}/></a>
            <a href={restaurant.social.x} aria-label="X">𝕏</a>
            <a href={restaurant.social.yelp} aria-label="Yelp">Y</a>
          </div>
          <p>{restaurant.phone}<br/>{restaurant.email}</p>
        </div>
        <div>
          <h4>Location</h4>
          <a className="map" href={restaurant.mapsUrl} target="_blank" rel="noreferrer">
            <strong>Google Maps Placeholder</strong><br/><br/>{restaurant.address}<br/><br/>Open in Google Maps →
          </a>
        </div>
      </div>
      <div className="copyright">© {new Date().getFullYear()} Roswell Ale House. Placeholder website content can be edited before launch.</div>
    </div>
  </footer>
}

'use client';

export default function HeroVideo(){
  const scrollToMenu = () => document.getElementById('home-menu')?.scrollIntoView({ behavior: 'smooth' });

  return <>
    <video
      className="hero-video"
      autoPlay
      muted
      loop
      playsInline
      preload="auto"
      poster="/hero-video-poster.png"
      aria-hidden="true"
    >
      <source src="/hero-video.mp4" type="video/mp4" />
    </video>
    <div className="hero-video-overlay" />
    <button className="hero-scroll" onClick={scrollToMenu} aria-label="Scroll to menu">⌄</button>
  </>;
}
